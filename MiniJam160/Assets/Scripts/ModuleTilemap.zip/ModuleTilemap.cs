using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class ModuleTilemap : MonoBehaviour {

    private Dictionary<Vector2Int, ModuleTile> tilemap = new Dictionary<Vector2Int, ModuleTile>();
    private HashSet<Vector2Int> tileLocations = new HashSet<Vector2Int>();

    [Serializable]
    public struct WeightedTile {
        public ModuleTile module;
        public int weight;
    }

    public List<WeightedTile> exposedGenericModules = new List<WeightedTile>();
    private Dictionary<ModuleTile, int> genericModules = new Dictionary<ModuleTile, int>();

    void Start() {
        for (int i = 0; i < exposedGenericModules.Count; i++) {
            genericModules.Add(exposedGenericModules[i].module, exposedGenericModules[i].weight);
        }
    }

    void Update() {
        
    }

    //Keep list of existing connectors

    //Select connector to place tile next to
    //Select tile to place at connector
    //   Rotate tile (EXTRA)
    //Find connectors in new tile and select one
    //See if it can be placed
    //   Rotate and try again (EXTRA)
    //If not choose new tile
    //Once placed:
    // check validity of existing connectors on and around placed tile
    // set tile origin
    // set extra tiles for reference as needed

    //All connectors with at least 1 tile of open space
    private List<Transform> existingConnectors = new List<Transform>();

    void RandomlyPlaceNewTile() {
        Transform selectedConnector = existingConnectors[Random.Range(0, existingConnectors.Count)];
        ModuleTile selectedTile = GetModuleTile();
        Transform connectorInNewTile = selectedTile.connectors[Random.Range(0, selectedTile.connectors.Count)];

        //Itterate thru all tiles that it'd take up
        for (int x = 0; x < selectedTile.moduleSize.x; x++) {
            for (int z = 0; x < selectedTile.moduleSize.y; z++) {

            }
        }
    }

    Vector2Int ConnectorTilePos(Transform connector) {
        return Vector2Int.zero;
    }

    ModuleTile GetModuleTile() {
        return MiniJam.WeightedRandom(genericModules);
    }
}
