using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModuleTile : MonoBehaviour {

    public Vector2Int moduleSize = Vector2Int.one;

    [HideInInspector] public Vector2Int origin;
    [HideInInspector] public List<Transform> connectors = new List<Transform>();

    void Start() {
        foreach (Transform connector in transform.Find("Connectors")) {
            connectors.Add(connector);
        }
    }

    void Update() {
        
    }

    public string GetName() {
        return transform.name;
    }
}
